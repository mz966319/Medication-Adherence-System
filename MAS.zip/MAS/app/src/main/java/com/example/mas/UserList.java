package com.example.mas;

import android.app.Activity;
import android.widget.ArrayAdapter;

import java.util.List;

public class UserList {
    private Activity context;
    private List<User> UserList;
    /*public UserList(Activity context, List<User> UserList){
        //super(context,R.layout, UserList);

    }*/
}
